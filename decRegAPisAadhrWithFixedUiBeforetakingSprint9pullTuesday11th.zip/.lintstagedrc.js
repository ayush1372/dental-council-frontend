module.exports = {
  '**/*.{js,jsx,ts,tsx}': [`eslint --fix`, `prettier --write`],
  '*': [`prettier --write --ignore-unknown`],
};
