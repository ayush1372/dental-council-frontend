# How to add React form hook to the Application

-For installation
npm install react-hook-form
-Created SignUp page in `/src/pages/signup/`
-export created SignUp page into `/src/pages/index.js`
