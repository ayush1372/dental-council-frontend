# Add new page called demo route

-Add demo route meta data into `/src/constants/NavigationMeta.js`

-Create demo folder in `/src/pages/demo`

# nesting part

-Create nested pages in in pages folder

-Path: `/src/pages/demo/sub-pages`

-Create individual components for Single & Multi dropdown.

-Nested pages export to `/src/pages/demo/index.js` (Parent file)

-Create Nav route in `/src/pages/demo/index.js` and call the nested components.

# benifits of nested routing

- users can easily redirect/navigate to the desired path without havoc.
