// import { Menu } from './menu';

// export default {
//   title: 'Menu',
//   component: Menu,
// };

// const Template = (args) => <Menu {...args}></Menu>;

// export const Playground = Template.bind({});
// Playground.args = {
//   variant: 'contained',
//   children: 'Playground',
// };
