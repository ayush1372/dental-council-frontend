import { render } from '@testing-library/react';

import LoginPage from '.';

test('renders', () => {
  render(<LoginPage />);
});
