export function Register() {
  return <>hi</>;
}

export default Register;
