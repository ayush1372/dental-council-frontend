/* PLOP_INJECT_PAGES_EXPORT */
import '../i18n';
export { SuspendValuntaryPopup } from './suspend-valuntary-popup';
export { VoluntarySuspendLicense } from './profile/sub-pages/voluntary-suspend-license/voluntary-suspend-license';
export { ScreenReader } from './screen-reader';
export { SuspendLicenseVoluntaryRetirement } from './suspend-license-voluntary-retirement';
export { Home } from './home';
export { PageNotFound } from './page-not-found';
export { Profile } from './profile';
export { UserProfile } from './user-profile';
export { Register } from './register';
