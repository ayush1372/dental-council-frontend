import { render } from '@testing-library/react';

import SuspendValuntaryPopup from './index';

test('renders', () => {
  render(<SuspendValuntaryPopup />);
});
