import { Box, Button, Typography } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { t } from 'i18next';
import { useForm } from 'react-hook-form';

import { TextField } from '../../../ui/core';

const ChangePassword = () => {
  const theme = useTheme();
  const {
    register,
    handleSubmit,
    getValues,
    onSubmit,
    watch,
    formState: { errors },
  } = useForm({
    mode: 'onChange',
    defaultValues: {
      newPassword: '',
      oldPassword: '',
      confirmPassword: '',
    },
  });
  return (
    <>
      <Typography color="primary" variant="h2" textAlign="center" mt={3}>
        Change Password
      </Typography>
      <Box
        sx={{
          width: {
            xs: '100%',
            md: '60%',
          },
          margin: {
            xs: 0,
            md: '10px auto',
          },
          backgroundColor: `${theme.palette.white.main}`,
          boxShadow: 4,
        }}
      >
        <Box p={2} boxShadow="1">
          <Box>
            <Box mt={2}>
              <Typography variant="body3" color="primary">
                {t('Old Password')}
                <Typography component="span" color="error.main">
                  *
                </Typography>
              </Typography>
              <TextField
                inputProps={{ maxLength: 100 }}
                fullWidth
                id="outlined-basic"
                variant="outlined"
                type="Password"
                name="oldPassword"
                required="true"
                placeholder={t('Old Password')}
                defaultValue={getValues().oldPassword}
                error={errors.oldPassword?.message}
                {...register('oldPassword', {
                  required: 'Enter old password',
                })}
              />
            </Box>
            <Box mt={2}>
              <Typography variant="body3" color="primary" mt={2}>
                {t('New Password')}
                <Typography component="span" color="error.main">
                  *
                </Typography>
              </Typography>
              <TextField
                inputProps={{ maxLength: 100 }}
                fullWidth
                id="outlined-basic"
                variant="outlined"
                type="Password"
                name="newPassword"
                required="true"
                placeholder={t('New Password')}
                defaultValue={getValues().newPassword}
                error={errors.newPassword?.message}
                {...register('newPassword', {
                  required: 'Enter new password',
                })}
              />
            </Box>
            <Box mt={2}>
              <Typography variant="body3" color="primary">
                {t('Confirm Password')}
                <Typography component="span" color="error.main">
                  *
                </Typography>
              </Typography>
              <TextField
                inputProps={{ maxLength: 100 }}
                fullWidth
                id="outlined-basic"
                variant="outlined"
                type="Password"
                name="confirmPassword"
                required="true"
                placeholder={t('Confirm Password')}
                defaultValue={getValues().confirmPassword}
                error={errors.confirmPassword?.message}
                {...register('confirmPassword', {
                  required: 'Enter confirm password',
                  validate: (val) => {
                    if (watch('newPassword') !== val) {
                      return 'Password does not match';
                    }
                  },
                })}
              />
            </Box>

            <Box align="center" mt={3}>
              <Button
                variant="contained"
                sx={{
                  backgroundColor: 'secondary.lightOrange',
                  '&:hover': {
                    backgroundColor: 'secondary.lightOrange',
                  },
                  width: {
                    xs: '100%',
                    md: 'fit-content',
                  },
                }}
                onClick={handleSubmit(onSubmit)}
              >
                {t('Submit')}
              </Button>
            </Box>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default ChangePassword;
