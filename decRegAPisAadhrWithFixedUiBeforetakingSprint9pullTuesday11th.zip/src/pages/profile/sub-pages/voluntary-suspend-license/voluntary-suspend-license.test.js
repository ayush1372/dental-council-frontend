import { render } from '@testing-library/react';

import VoluntarySuspendLicense from './voluntary-suspend-license';

test('renders', () => {
  render(<VoluntarySuspendLicense />);
});
