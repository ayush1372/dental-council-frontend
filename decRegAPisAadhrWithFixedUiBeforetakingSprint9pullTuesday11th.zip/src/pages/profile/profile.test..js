import { render } from '@testing-library/react';

import ProfileNew from './index';

test('renders', () => {
  render(<ProfileNew />);
});
