export const breakpoints = {
  values: {
    xs: 375,
    sm: 768,
    md: 1024,
    lg: 1366,
    xl: 1440,
  },
};
