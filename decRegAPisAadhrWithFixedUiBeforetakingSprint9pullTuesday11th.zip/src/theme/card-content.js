export const CardContent = () => ({
  styleOverrides: {
    root: {
      padding: '0',
      marginTop: '10px',
      '&:last-child': {
        padding: '0',
      },
    },
  },
});
