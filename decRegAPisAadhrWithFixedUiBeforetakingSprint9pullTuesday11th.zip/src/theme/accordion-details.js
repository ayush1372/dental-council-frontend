export const AccordionDetails = () => ({
  styleOverrides: {
    root: {
      paddingLeft: '24px',
      paddingRight: '24px',
      paddingTop: '0',
    },
  },
});
