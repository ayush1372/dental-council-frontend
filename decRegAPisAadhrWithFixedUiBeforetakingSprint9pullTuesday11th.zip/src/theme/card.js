export const Card = () => ({
  styleOverrides: {
    root: {
      borderRadius: '10px',
      boxShadow: ' 0 1px 3px #26262666',
      padding: '24px',
    },
  },
});
