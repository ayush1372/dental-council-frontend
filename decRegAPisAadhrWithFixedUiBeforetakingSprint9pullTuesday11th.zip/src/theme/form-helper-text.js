export const FormHelperText = () => ({
  styleOverrides: {
    root: {
      marginLeft: '0',
      '&.Mui-error': {
        display: 'flex',
        width: '100%',
      },
    },
  },
});
