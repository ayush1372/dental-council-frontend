export const CardActions = () => ({
  styleOverrides: {
    root: {
      padding: '0',
      marginTop: '24px',
    },
  },
});
