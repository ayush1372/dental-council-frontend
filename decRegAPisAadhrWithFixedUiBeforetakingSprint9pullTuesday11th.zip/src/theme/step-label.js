export const StepLabel = () => ({
  styleOverrides: {
    root: {
      '& .MuiStepLabel-label': {
        fontWeight: 700,
      },
    },
  },
});
